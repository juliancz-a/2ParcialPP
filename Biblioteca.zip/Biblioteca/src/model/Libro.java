
package model;

import service.CSVSerializable;
import java.io.Serializable;



public class Libro implements Comparable<Libro>, CSVSerializable, Serializable{
    private static final long serialVersionUID = 1L;
    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int id, String titulo, String autor, Categoria categoria) {
        this.id = id;
        
        checkId(id);
        
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    @Override
    // -> orden natural de ordenamiento (por id)
    public int compareTo(Libro other) {
       return Integer.compare(id, other.id);
    }

    @Override
    public String toString() {
        return "Libro{" + "id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", categoria=" + categoria + '}';
    }

    @Override
    public String toCSV() {
        return id  +  "," + titulo + "," + autor +  "," + categoria;
    }
  
    public static Libro fromCSV(String CSVString) {
       
       String[] data = CSVString.split(",");
       
       if(!(data.length == 4)) {
           throw new RuntimeException("ERROR: Un libro posee atributos incorrectos para su importación");
       }
       
       int id = Integer.parseInt(data[0]);
       if(id < 0){
           throw new RuntimeException("ERROR: Un libro posee un id inválido");
       }
       
       
       return new Libro(id, data[1], (data[2]), Categoria.valueOf(data[3]));     
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public String getTitulo() {
        return titulo;
    }
    
    private void checkId(int id) {
        if(id < 0){
           throw new RuntimeException("ERROR: Un libro posee un id inválido");
       }
    }
    
    

    
    
    
}
