
package service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Inventariable<T> {
    
     void agregarItem(T item);
     
     void eliminarItem(int index);
     
    T obtenerItem(int index);  
    
    void ordenarItems();
    
    void ordenarItems(Comparator<? super T> c);

    List<T> filtrarItems(Predicate<? super T> criterio);
    
    void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException, FileNotFoundException;
    
    void guardarEnArchivo(String path) throws IOException;
    
    void guardarEnCSV(String path)throws IOException;
    
    void cargarDesdeCSV(String path, Function<String, T> constructor)throws IOException, FileNotFoundException ;

    void paraCadaElemento(Consumer<? super T> consumidor);
    
    
}
