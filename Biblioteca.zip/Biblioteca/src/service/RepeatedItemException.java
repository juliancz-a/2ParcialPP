package service;

public class RepeatedItemException extends RuntimeException{
    private static final String MESSAGE = "Item repetido";

    public RepeatedItemException() {
        super(MESSAGE);
    }
    
    
}
